# Bootstrap to the main module
if __name__ == '__main__':
    from main import main
    main()